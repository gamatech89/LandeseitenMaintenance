<?php
/**
 * REST API endpoints for Landeseiten Maintenance.
 *
 * @package Landeseiten_Maintenance
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * LSM API class.
 */
class LSM_API {

    /**
     * API namespace.
     */
    const NAMESPACE = 'lsm/v1';

    /**
     * Register routes.
     */
    public function register_routes() {
        // Public info endpoint
        register_rest_route(self::NAMESPACE, '/info', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_info'],
            'permission_callback' => '__return_true',
        ]);

        // Authenticated endpoints
        register_rest_route(self::NAMESPACE, '/health', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_health'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/sso/token', [
            'methods'             => 'POST',
            'callback'            => [$this, 'generate_sso_token'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/cache/clear', [
            'methods'             => 'POST',
            'callback'            => [$this, 'clear_cache'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/database/optimize', [
            'methods'             => 'POST',
            'callback'            => [$this, 'optimize_database'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/rewrite/flush', [
            'methods'             => 'POST',
            'callback'            => [$this, 'flush_rewrite'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/updates', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_updates'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/plugins', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_plugins'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/themes', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_themes'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/transients/clear', [
            'methods'             => 'POST',
            'callback'            => [$this, 'clear_transients'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/updates/plugins', [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_plugins'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/updates/core', [
            'methods'             => 'POST',
            'callback'            => [$this, 'update_core'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/maintenance/enable', [
            'methods'             => 'POST',
            'callback'            => [$this, 'enable_maintenance'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/maintenance/disable', [
            'methods'             => 'POST',
            'callback'            => [$this, 'disable_maintenance'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/recovery/disable-plugins', [
            'methods'             => 'POST',
            'callback'            => [$this, 'disable_plugins'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/recovery/restore-plugins', [
            'methods'             => 'POST',
            'callback'            => [$this, 'restore_plugins'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/recovery/emergency', [
            'methods'             => 'POST',
            'callback'            => [$this, 'emergency_recovery'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        // Backup endpoints
        register_rest_route(self::NAMESPACE, '/backup/create', [
            'methods'             => 'POST',
            'callback'            => [$this, 'create_backup'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/backup/list', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_backups'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/backup/download', [
            'methods'             => 'GET',
            'callback'            => [$this, 'download_backup'],
            'permission_callback' => '__return_true', // Uses token auth
        ]);

        register_rest_route(self::NAMESPACE, '/backup/restore', [
            'methods'             => 'POST',
            'callback'            => [$this, 'restore_backup'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/backup/delete', [
            'methods'             => 'POST',
            'callback'            => [$this, 'delete_backup'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        // PHP Error endpoints
        register_rest_route(self::NAMESPACE, '/errors/list', [
            'methods'             => 'GET',
            'callback'            => [$this, 'list_errors'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/errors/stats', [
            'methods'             => 'GET',
            'callback'            => [$this, 'get_error_stats'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/errors/resolve', [
            'methods'             => 'POST',
            'callback'            => [$this, 'resolve_error'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/errors/delete', [
            'methods'             => 'POST',
            'callback'            => [$this, 'delete_error'],
            'permission_callback' => [$this, 'authenticate'],
        ]);

        register_rest_route(self::NAMESPACE, '/errors/clear', [
            'methods'             => 'POST',
            'callback'            => [$this, 'clear_errors'],
            'permission_callback' => [$this, 'authenticate'],
        ]);
    }


    /**
     * Authenticate API request.
     *
     * @param WP_REST_Request $request Request object.
     * @return bool
     */
    public function authenticate($request) {
        $api_key = Landeseiten_Maintenance::get_setting('api_key');
        if (empty($api_key)) {
            return false;
        }

        // Check query param
        $key = $request->get_param('key');
        if ($key === $api_key) {
            return true;
        }

        // Check header
        $auth_header = $request->get_header('X-LSM-Key');
        if ($auth_header === $api_key) {
            return true;
        }

        // Check Authorization header
        $auth = $request->get_header('Authorization');
        if ($auth && preg_match('/^Bearer\s+(.+)$/i', $auth, $matches)) {
            if ($matches[1] === $api_key) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get plugin info.
     */
    public function get_info() {
        return rest_ensure_response([
            'success' => true,
            'data'    => [
                'plugin'  => 'Landeseiten Maintenance',
                'version' => LSM_VERSION,
                'status'  => 'active',
            ],
        ]);
    }

    /**
     * Get health data.
     */
    public function get_health() {
        $health = new LSM_Health();
        return rest_ensure_response([
            'success' => true,
            'data'    => $health->get_health_data(),
        ]);
    }

    /**
     * Generate SSO token.
     *
     * @param WP_REST_Request $request Request.
     */
    public function generate_sso_token($request) {
        $auth = new LSM_Auth();
        $token_data = $auth->generate_login_token(
            $request->get_param('role') ?? 'administrator',
            $request->get_param('expires_in') ?? 300,
            $request->get_param('bind_ip'),
            $request->get_param('dashboard_user')
        );

        return rest_ensure_response([
            'success'   => true,
            'login_url' => $token_data['login_url'],
            'expires'   => $token_data['expires'],
        ]);
    }

    /**
     * Clear cache.
     */
    public function clear_cache() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::clear_cache(),
        ]);
    }

    /**
     * Optimize database.
     */
    public function optimize_database() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::optimize_database(),
        ]);
    }

    /**
     * Flush rewrite rules.
     */
    public function flush_rewrite() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::flush_rewrite(),
        ]);
    }

    /**
     * Get updates.
     */
    public function get_updates() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::get_updates(),
        ]);
    }

    /**
     * Get all installed plugins with enhanced details.
     */
    public function get_plugins() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        if (!function_exists('get_plugin_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }

        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins', []);
        $auto_update_plugins = get_option('auto_update_plugins', []);
        $plugin_updates = get_plugin_updates();
        
        // Get cached plugin info from WordPress.org
        $plugin_info_cache = get_transient('lsm_plugin_info_cache') ?: [];
        
        $plugins = [];
        
        foreach ($all_plugins as $plugin_file => $plugin_data) {
            // Extract slug from plugin file path
            $slug = dirname($plugin_file);
            if ($slug === '.') {
                $slug = basename($plugin_file, '.php');
            }
            
            // Get update info
            $update_available = isset($plugin_updates[$plugin_file]);
            $new_version = $update_available ? $plugin_updates[$plugin_file]->update->new_version : null;
            
            // Get icon from WordPress.org (cached)
            $icon = null;
            if (!isset($plugin_info_cache[$slug])) {
                $api_response = wp_remote_get(
                    "https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&slug={$slug}",
                    ['timeout' => 5]
                );
                if (!is_wp_error($api_response)) {
                    $body = json_decode(wp_remote_retrieve_body($api_response), true);
                    if (!empty($body) && !isset($body['error'])) {
                        $plugin_info_cache[$slug] = [
                            'icon' => $body['icons']['1x'] ?? $body['icons']['svg'] ?? $body['icons']['default'] ?? null,
                            'rating' => $body['rating'] ?? null,
                            'num_ratings' => $body['num_ratings'] ?? 0,
                            'active_installs' => $body['active_installs'] ?? null,
                            'last_updated' => $body['last_updated'] ?? null,
                        ];
                    }
                }
            }
            
            $cached_info = $plugin_info_cache[$slug] ?? [];
            
            $plugins[] = [
                'slug'             => $slug,
                'plugin'           => $plugin_file,
                'name'             => $plugin_data['Name'],
                'version'          => $plugin_data['Version'],
                'new_version'      => $new_version,
                'update_available' => $update_available,
                'author'           => strip_tags($plugin_data['Author']),
                'author_url'       => $plugin_data['AuthorURI'] ?? '',
                'description'      => $plugin_data['Description'],
                'active'           => in_array($plugin_file, $active_plugins, true),
                'auto_update'      => in_array($plugin_file, $auto_update_plugins, true),
                'url'              => $plugin_data['PluginURI'] ?? '',
                'requires_wp'      => $plugin_data['RequiresWP'] ?? null,
                'requires_php'     => $plugin_data['RequiresPHP'] ?? null,
                'icon'             => $cached_info['icon'] ?? null,
                'rating'           => $cached_info['rating'] ?? null,
                'active_installs'  => $cached_info['active_installs'] ?? null,
                'last_updated'     => $cached_info['last_updated'] ?? null,
            ];
        }
        
        // Cache plugin info for 1 hour
        set_transient('lsm_plugin_info_cache', $plugin_info_cache, HOUR_IN_SECONDS);
        
        return rest_ensure_response([
            'success' => true,
            'data'    => $plugins,
        ]);
    }

    /**
     * Get all installed themes with details.
     */
    public function get_themes() {
        if (!function_exists('wp_get_themes')) {
            require_once ABSPATH . 'wp-includes/theme.php';
        }
        if (!function_exists('get_theme_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }

        $all_themes = wp_get_themes();
        $active_theme = wp_get_theme();
        $theme_updates = get_theme_updates();
        
        $themes = [];
        
        foreach ($all_themes as $stylesheet => $theme) {
            $update_available = isset($theme_updates[$stylesheet]);
            $new_version = $update_available ? $theme_updates[$stylesheet]->update['new_version'] : null;
            
            $themes[] = [
                'slug'             => $stylesheet,
                'name'             => $theme->get('Name'),
                'version'          => $theme->get('Version'),
                'new_version'      => $new_version,
                'update_available' => $update_available,
                'author'           => $theme->get('Author'),
                'author_url'       => $theme->get('AuthorURI'),
                'description'      => $theme->get('Description'),
                'active'           => ($active_theme->get_stylesheet() === $stylesheet),
                'template'         => $theme->get('Template'),
                'screenshot'       => $theme->get_screenshot(),
                'requires_wp'      => $theme->get('RequiresWP'),
                'requires_php'     => $theme->get('RequiresPHP'),
            ];
        }
        
        return rest_ensure_response([
            'success' => true,
            'data'    => $themes,
        ]);
    }

    /**
     * Clear transients from the database.
     */
    public function clear_transients(WP_REST_Request $request) {
        global $wpdb;
        
        $all = $request->get_param('all') === true || $request->get_param('all') === 'true';
        
        if ($all) {
            // Clear all transients
            $count = $wpdb->query(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_%' OR option_name LIKE '_site_transient_%'"
            );
        } else {
            // Clear only expired transients
            $time = time();
            $expired_transients = $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT option_name FROM {$wpdb->options} 
                     WHERE option_name LIKE '_transient_timeout_%' 
                     AND option_value < %d",
                    $time
                )
            );
            
            $count = 0;
            foreach ($expired_transients as $transient) {
                $transient_name = str_replace('_transient_timeout_', '', $transient);
                delete_transient($transient_name);
                $count++;
            }
        }
        
        LSM_Logger::log('transients_cleared', 'success', [
            'count' => $count,
            'all'   => $all,
        ]);
        
        return rest_ensure_response([
            'success' => true,
            'data'    => [
                'cleared' => $count,
                'all'     => $all,
                'message' => sprintf(__('Cleared %d transient(s).', 'landeseiten-maintenance'), $count),
            ],
        ]);
    }

    /**
     * Update plugins.
     */
    public function update_plugins() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::update_all_plugins(),
        ]);
    }

    /**
     * Update core.
     */
    public function update_core() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Actions::update_core(),
        ]);
    }

    /**
     * Enable maintenance mode.
     */
    public function enable_maintenance() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Maintenance_Mode::enable(),
        ]);
    }

    /**
     * Disable maintenance mode.
     */
    public function disable_maintenance() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Maintenance_Mode::disable(),
        ]);
    }

    /**
     * Disable all plugins.
     */
    public function disable_plugins() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Recovery::disable_all_plugins(),
        ]);
    }

    /**
     * Restore plugins.
     */
    public function restore_plugins() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Recovery::restore_plugins(),
        ]);
    }

    /**
     * Emergency recovery.
     */
    public function emergency_recovery() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Recovery::emergency_recovery(),
        ]);
    }

    // =========================================================================
    // BACKUP METHODS
    // =========================================================================

    /**
     * Create a backup.
     *
     * @param WP_REST_Request $request Request.
     */
    public function create_backup($request) {
        $options = [
            'includes_database' => $request->get_param('includes_database') ?? true,
            'includes_files'    => $request->get_param('includes_files') ?? true,
            'includes_uploads'  => $request->get_param('includes_uploads') ?? true,
        ];

        $result = LSM_Backup::create_backup($options);

        return rest_ensure_response([
            'success' => $result['success'],
            'data'    => $result,
        ]);
    }

    /**
     * List available backups.
     */
    public function list_backups() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Backup::list_backups(),
        ]);
    }

    /**
     * Download a backup.
     *
     * @param WP_REST_Request $request Request.
     */
    public function download_backup($request) {
        $token = $request->get_param('token');
        
        if (empty($token)) {
            return new WP_Error('missing_token', 'Download token is required', ['status' => 400]);
        }

        $backup_path = LSM_Backup::get_backup_by_token($token);
        
        if (!$backup_path) {
            return new WP_Error('invalid_token', 'Invalid or expired download token', ['status' => 403]);
        }

        // Serve the file
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($backup_path) . '"');
        header('Content-Length: ' . filesize($backup_path));
        header('Cache-Control: no-cache, must-revalidate');

        readfile($backup_path);
        exit;
    }

    /**
     * Restore a backup.
     *
     * @param WP_REST_Request $request Request.
     */
    public function restore_backup($request) {
        $filename = $request->get_param('backup_file');
        
        if (empty($filename)) {
            return new WP_Error('missing_filename', 'Backup filename is required', ['status' => 400]);
        }

        $result = LSM_Backup::restore_backup($filename);

        return rest_ensure_response([
            'success' => $result['success'],
            'data'    => $result,
        ]);
    }

    /**
     * Delete a backup.
     *
     * @param WP_REST_Request $request Request.
     */
    public function delete_backup($request) {
        $filename = $request->get_param('backup_file');
        
        if (empty($filename)) {
            return new WP_Error('missing_filename', 'Backup filename is required', ['status' => 400]);
        }

        $success = LSM_Backup::delete_backup($filename);

        return rest_ensure_response([
            'success' => $success,
            'message' => $success ? 'Backup deleted' : 'Failed to delete backup',
        ]);
    }

    // =========================================================================
    // PHP ERROR METHODS
    // =========================================================================

    /**
     * List PHP errors.
     *
     * @param WP_REST_Request $request Request.
     */
    public function list_errors($request) {
        $filters = [
            'type'       => $request->get_param('type'),
            'unresolved' => $request->get_param('unresolved'),
            'search'     => $request->get_param('search'),
        ];

        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Php_Errors::get_errors($filters),
        ]);
    }

    /**
     * Get error statistics.
     */
    public function get_error_stats() {
        return rest_ensure_response([
            'success' => true,
            'data'    => LSM_Php_Errors::get_stats(),
        ]);
    }

    /**
     * Resolve an error.
     *
     * @param WP_REST_Request $request Request.
     */
    public function resolve_error($request) {
        $hash = $request->get_param('hash');
        
        if (empty($hash)) {
            return new WP_Error('missing_hash', 'Error hash is required', ['status' => 400]);
        }

        $success = LSM_Php_Errors::resolve_error($hash);

        return rest_ensure_response([
            'success' => $success,
            'message' => $success ? 'Error resolved' : 'Error not found',
        ]);
    }

    /**
     * Delete an error.
     *
     * @param WP_REST_Request $request Request.
     */
    public function delete_error($request) {
        $hash = $request->get_param('hash');
        
        if (empty($hash)) {
            return new WP_Error('missing_hash', 'Error hash is required', ['status' => 400]);
        }

        $success = LSM_Php_Errors::delete_error($hash);

        return rest_ensure_response([
            'success' => $success,
            'message' => $success ? 'Error deleted' : 'Error not found',
        ]);
    }

    /**
     * Clear all errors.
     */
    public function clear_errors() {
        LSM_Php_Errors::clear_errors();

        return rest_ensure_response([
            'success' => true,
            'message' => 'All errors cleared',
        ]);
    }
}
